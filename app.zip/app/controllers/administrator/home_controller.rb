class Administrator::HomeController < AdministratorsController
	def index
	end
end
