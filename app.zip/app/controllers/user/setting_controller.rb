class User::SettingController < UsersController
  def show
  end

  def update
  end
end
