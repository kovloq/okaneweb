class User::ReportController < Usersontroller
  def index
  end

  def new
  end

  def create
  end
end
