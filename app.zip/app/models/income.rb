class Income < ActiveRecord::Base
end
