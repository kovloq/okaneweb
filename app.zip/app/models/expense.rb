class Expense < ActiveRecord::Base
end
