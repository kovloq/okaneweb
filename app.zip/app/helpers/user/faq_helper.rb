module User::FaqHelper
end
