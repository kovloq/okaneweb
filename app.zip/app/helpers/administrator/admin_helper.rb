module Administrator::AdminHelper
end
